var config = {
    deps: [
        "RLTSquare_Unit3/js/main"
    ]
};
